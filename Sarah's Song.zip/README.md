# Sarah-s-Song

 ## My project for the swift student challenge 2025, A virtual keyboard with haptic feedback for people with hearing impairments to play music.

- My project focuses on the use of haptic feedback, so if possible, please test it on an iPhone device, as this experience will not be available in the simulator.

- I developed it using the iPhone 16 Pro Max as a reference, but I tried to make it as responsive as possible in case this specific device is not available.

- The melody played when clicking the "Demo" button is Für Elise by Ludwig van Beethoven, and it is in the public domain.

- All other components, assets, music, and fonts are my own work.
